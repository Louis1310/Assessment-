package com.example.walmart.presentation.details

object CountryDetailsArg {

    const val COUNTRY_CODE = "country-code"
}