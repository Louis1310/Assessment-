package com.example.walmart.presentation.details

import androidx.fragment.app.testing.FragmentScenario
import androidx.fragment.app.testing.launchFragmentInContainer
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.example.walmart.domain.di.ServiceProvider
import com.example.walmart.domain.model.Country
import com.example.walmart.presentation.R
import io.mockk.MockKAnnotations
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkObject
import io.mockk.verify
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.test.runTest
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import android.widget.TextView
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.google.common.truth.Truth.assertThat

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class CountryDetailsFragmentTest {

    private lateinit var viewModel: CountryDetailsViewModel
    private val stateFlow = MutableStateFlow(CountryDetailsViewModel.State())
    private val effectFlow = MutableSharedFlow<CountryDetailsViewModel.Effect>()

    @Before
    fun setUp() {
        MockKAnnotations.init(this)
        viewModel = mockk(relaxed = true)
        every { viewModel.state } returns stateFlow
        every { viewModel.effectFlow } returns effectFlow

        // Mock the ViewModelFactory to return the mocked ViewModel
        val factory = mockk<ViewModelProvider.Factory>()
        every { factory.create(CountryDetailsViewModel::class.java, any()) } returns viewModel

        // Mock the ServiceProvider to return the mocked Factory
        mockkObject(ServiceProvider)
        every { ServiceProvider.get<CountryDetailsViewModelFactory>() } returns factory
    }

    @Test
    fun `displays country details correctly`() {
        // Given
        val country = Country(
            code = "US",
            name = "United States of America",
            region = "NA",
            capital = "Washington, D.C."
        )
        stateFlow.value = CountryDetailsViewModel.State(
            loading = false,
            country = country,
            errorMessage = null
        )

        // When
        val scenario: FragmentScenario<CountryDetailsFragment> =
            launchFragmentInContainer(themeResId = R.style.Theme_WallmartExample) {
                CountryDetailsFragment().apply {
                    // The mocked ViewModel is injected via the mocked ServiceProvider
                }
            }

        // Then
        scenario.onFragment { fragment ->
            val view = fragment.view
            // Ensure the view is not null
            assertThat(view).isNotNull()

            // Access the views using findViewById
            val nameWithRegionView: TextView? = view?.findViewById(R.id.name_with_region_view)
            val codeView: TextView? = view?.findViewById(R.id.code_view)
            val capitalView: TextView? = view?.findViewById(R.id.capital_view)
            val swipeRefreshLayout: View? = view?.findViewById(R.id.swipe_refresh_layout)
            val errorMessage: TextView? = view?.findViewById(R.id.error_message)

            // Perform assertions using Truth
            assertThat(nameWithRegionView?.text).isEqualTo("United States of America, NA")
            assertThat(codeView?.text).isEqualTo("US")
            assertThat(capitalView?.text).isEqualTo("Washington, D.C.")
            assertThat(
                (swipeRefreshLayout as? androidx.swiperefreshlayout.widget.SwipeRefreshLayout)?.isRefreshing
            ).isFalse()
            assertThat(errorMessage?.visibility).isEqualTo(View.GONE)
        }
    }

    @Test
    fun `shows loading spinner when loading is true`() {
        // Given
        stateFlow.value = CountryDetailsViewModel.State(
            loading = true,
            country = null,
            errorMessage = null
        )

        // When
        val scenario: FragmentScenario<CountryDetailsFragment> =
            launchFragmentInContainer(themeResId = R.style.Theme_WallmartExample) {
                CountryDetailsFragment().apply {
                    // The mocked ViewModel is injected via the mocked ServiceProvider
                }
            }

        // Then
        scenario.onFragment { fragment ->
            val view = fragment.view
            // Ensure the view is not null
            assertThat(view).isNotNull()

            // Access the SwipeRefreshLayout
            val swipeRefreshLayout: androidx.swiperefreshlayout.widget.SwipeRefreshLayout? =
                view?.findViewById(R.id.swipe_refresh_layout)

            // Perform assertion using Truth
            assertThat(swipeRefreshLayout?.isRefreshing).isTrue()
        }
    }

    @Test
    fun `displays error message when error occurs`() {
        // Given
        stateFlow.value = CountryDetailsViewModel.State(
            loading = false,
            country = null,
            errorMessage = "An error occurred"
        )

        // When
        val scenario: FragmentScenario<CountryDetailsFragment> =
            launchFragmentInContainer(themeResId = R.style.Theme_WallmartExample) {
                CountryDetailsFragment().apply {
                    // The mocked ViewModel is injected via the mocked ServiceProvider
                }
            }

        // Then
        scenario.onFragment { fragment ->
            val view = fragment.view
            // Ensure the view is not null
            assertThat(view).isNotNull()

            // Access the error message TextView
            val errorMessage: TextView? = view?.findViewById(R.id.error_message)

            // Perform assertions using Truth
            assertThat(errorMessage?.text).isEqualTo("An error occurred")
            assertThat(errorMessage?.visibility).isEqualTo(View.VISIBLE)
        }
    }

    @Test
    fun `navigates back when back button is clicked`() = runTest {
        // Given
        val mockNavController = mockk<NavController>(relaxed = true)

        // When
        val scenario: FragmentScenario<CountryDetailsFragment> =
            launchFragmentInContainer(themeResId = R.style.Theme_WallmartExample) {
                CountryDetailsFragment().apply {
                    // The mocked ViewModel is injected via the mocked ServiceProvider
                }
            }

        scenario.onFragment { fragment ->
            // Set the mocked NavController to the fragment's view
            Navigation.setViewNavController(fragment.view, mockNavController)
            // Simulate the ViewModel sending an OnBack effect
            viewModel.onBackClicked()
        }

        // Then
        verify { mockNavController.popBackStack() }
    }
}