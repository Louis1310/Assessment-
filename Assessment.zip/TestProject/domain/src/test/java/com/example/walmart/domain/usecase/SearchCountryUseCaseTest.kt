package com.example.walmart.domain.usecase

import com.example.walmart.domain.model.Country
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.Parameterized

@RunWith(Parameterized::class)
class SearchCountryUseCaseTest(private val countries: List<Country>,
                               private val query: String,
                               private val expected: List<Country>) {

    companion object {
        @JvmStatic
        @Parameterized.Parameters
        fun data(): List<Array<Any>> {
            return listOf(
                // Test case where query is "America"
                arrayOf(
                    listOf(
                        Country("USA", "North America", "US", "Washington, D.C."),
                        Country("Canada", "North America", "CA", "Ottawa"),
                        Country("Brazil", "South America", "BR", "Brasília")
                    ),
                    "America",
                    // Updated expected results to include Brazil
                    listOf(
                        Country("USA", "North America", "US", "Washington, D.C."),
                        Country("Canada", "North America", "CA", "Ottawa"),
                        Country("Brazil", "South America", "BR", "Brasília")
                    )
                ),
                // Other test cases remain the same
                arrayOf(
                    listOf(
                        Country("USA", "North America", "US", "Washington, D.C."),
                        Country("Canada", "North America", "CA", "Ottawa"),
                        Country("Brazil", "South America", "BR", "Brasília")
                    ),
                    "",
                    listOf(
                        Country("USA", "North America", "US", "Washington, D.C."),
                        Country("Canada", "North America", "CA", "Ottawa"),
                        Country("Brazil", "South America", "BR", "Brasília")
                    )
                ),
                arrayOf(
                    emptyList<Country>(),
                    "Europe",
                    emptyList<Country>()
                ),
                arrayOf(
                    listOf(
                        Country("USA", "North America", "US", "Washington, D.C."),
                        Country("Canada", "North America", "CA", "Ottawa"),
                        Country("Brazil", "South America", "BR", "Brasília")
                    ),
                    "Europe",
                    emptyList<Country>()
                ),
                arrayOf(
                    listOf(
                        Country("USA", "North America", "US", "Washington, D.C."),
                        Country("Canada", "North America", "CA", "Ottawa"),
                        Country("Brazil", "South America", "BR", "Brasília")
                    ),
                    "brazil",
                    listOf(
                        Country("Brazil", "South America", "BR", "Brasília")
                    )
                )
            )
        }
    }

    @Test
    fun `test search`() {
        val useCase = SearchCountryUseCase()
        val result = useCase(countries, query)
        assertEquals(expected, result)
    }


}
